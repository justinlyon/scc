<?php

/**
 * $Id: common.php 1001 2006-06-07 00:30:17Z nauhygon $
 * 
 * Copyright(c) 2005 by Oak Nauhygon. All rights reserved.
 * 
 * @author Oak Nauhygon <ezpdo4php@gmail.com>
 * @version $Revision$ $Date: 2006-06-06 20:30:17 -0400 (Tue, 06 Jun 2006) $
 * @package ezpdo_bench
 * @subpackage ezpdo_bench.books
 */

/**
 * Include common benchmarking functions
 */
include_once('../common.php');

// define parameters
define('NUM_AUTHORS', 10);
define('NUM_BOOKS', 10);

?>
