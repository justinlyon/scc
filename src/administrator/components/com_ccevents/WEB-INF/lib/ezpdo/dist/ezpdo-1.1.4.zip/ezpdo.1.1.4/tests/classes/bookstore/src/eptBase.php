<?php

/**
 * $Id: eptBase.php 347 2005-07-24 04:06:16Z nauhygon $
 * 
 * Copyright(c) 2005 by Oak Nauhygon. All rights reserved.
 * 
 * @author Oak Nauhygon <ezpdo4php@gmail.com>
 * @version $Revision$ $Date: 2005-07-24 00:06:16 -0400 (Sun, 24 Jul 2005) $
 * @package ezpdo_t
 * @subpackage ezpdo_t.bookstore
 */

/**
 * Base class of ezpdo test
 * 
 * @author Oak Nauhygon <ezpdo4php@gmail.com>
 * @version $Revision$ $Date: 2005-07-24 00:06:16 -0400 (Sun, 24 Jul 2005) $
 * @package ezpdo_t
 * @subpackage ezpdo_t.bookstore
 */
class eptBase {
    
    /**
     * uuid
     * @var string
     * @orm char(64)
     */
    public $uuid;
    
    /**
     * Constructor
     * @param string $name author name
     */
    public function __construct() { 
        $this->uuid = md5(uniqid());
    } 

}

?>
